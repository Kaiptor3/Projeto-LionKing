// Funções para a navegação dos slides
let currentSlide = 0;
const slides = document.querySelectorAll('.slide-box');
const totalSlides = slides.length;

document.getElementById('nextBtn').addEventListener('click', function() {
    changeSlide(1);
});

document.getElementById('prevBtn').addEventListener('click', function() {
    changeSlide(-1);
});

function changeSlide(direction) {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide + direction + totalSlides) % totalSlides; // Circula entre os slides
    slides[currentSlide].classList.add('active');
}
const button = document.getElementById('toggleButton');
const footerCollapse = document.getElementById('footerCollapse');

button.addEventListener('click', () => {
    footerCollapse.classList.toggle('hidden');
    button.textContent = footerCollapse.classList.contains('hidden') ? 'Mostrar detalhes' : 'Menos detalhes';
});
