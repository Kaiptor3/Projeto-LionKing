// Seleciona os elementos do DOM
const slides = document.querySelectorAll('.slide-box');
const nextBtn = document.getElementById('nextBtn');
const prevBtn = document.getElementById('prevBtn');

let currentSlide = 0;

// Função para mostrar o slide atual
function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
    });
}

// Função para ir para o próximo slide
function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length; // Volta ao primeiro slide se for o último
    showSlide(currentSlide);
}

// Função para ir para o slide anterior
function prevSlide() {
    currentSlide = (currentSlide - 1 + slides.length) % slides.length; // Vai para o último slide se estiver no primeiro
    showSlide(currentSlide);
}

// Adiciona os eventos de clique nos botões
nextBtn.addEventListener('click', nextSlide);
prevBtn.addEventListener('click', prevSlide);

// Inicializa o primeiro slide
showSlide(currentSlide);
