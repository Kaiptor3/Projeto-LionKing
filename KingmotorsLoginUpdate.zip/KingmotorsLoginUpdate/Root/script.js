let currentSlide = 0;
const slides = document.querySelectorAll('.slide-box');
const totalSlides = slides.length;

// Mostrar apenas o primeiro slide
slides[currentSlide].classList.add('active');

document.getElementById('nextBtn').addEventListener('click', () => {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide + 1) % totalSlides;
    slides[currentSlide].classList.add('active');
});

document.getElementById('prevBtn').addEventListener('click', () => {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    slides[currentSlide].classList.add('active');
});
